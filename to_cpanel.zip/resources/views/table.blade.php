<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Table</title>
</head>
<body>
	<table>
		<thead>
			<th>No.</th>
			<th>Nama</th>
		</thead>
		<tbody>
			<tr>
				<td>1</td>
				<td>Uhuy</td>
			</tr>
			<tr>
				<td>1</td>
				<td>Uhuy</td>
			</tr>
			<tr>
				<td>1</td>
				<td>Uhuy</td>
			</tr>
			<tr>
				<td>1</td>
				<td>Uhuy</td>
			</tr>
		</tbody>
	</table>
</body>
</html>